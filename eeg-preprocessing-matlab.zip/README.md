# EEG Signal Preprocessing in MATLAB

This project demonstrates a simple MATLAB-based EEG preprocessing pipeline.

## Features

- Bandpass filtering (1–40 Hz)
- Artifact detection and interpolation
- Power Spectral Density (PSD) plotting
- Band power feature extraction (Delta, Theta, Alpha, Beta)

## How to Run

1. Open MATLAB.
2. Go to `code/` directory.
3. Run:
   ```matlab
   eeg_signal_processing
   ```

4. Outputs will be saved in the `results/` folder.

## Folders

- `code/`: MATLAB script
- `data/`: EEG `.mat` file
- `results/`: Output figures and features

## Requirements

- MATLAB R2020b or later
- Signal Processing Toolbox
